import React, { useState } from 'react';
import { View, ScrollView, Pressable, Switch, I18nManager } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, ChevronRight, CircleOff, LogOut, ScanFace } from 'lucide-react-native';
import { ConfirmModal } from './components';
import { NavigationState } from '@/navigation/RootNavigator';

interface SecurityScreenProps {
  onBack?: () => void;
  onNavigate?: (key: NavigationState) => void;
}

export const SecurityScreen: React.FC<SecurityScreenProps> = ({ onBack, onNavigate }) => {
  const { t, i18n } = useTranslation();
  const isRTL = typeof i18n.dir === 'function' ? i18n.dir(i18n.language) === 'rtl' : I18nManager.isRTL;
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const [appSecurityEnabled, setAppSecurityEnabled] = useState(true);

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <View
        className="items-center px-3 pt-4 pb-2"
        style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center' }}
      >
        <Pressable onPress={onBack} hitSlop={10} className="p-2">
          {isRTL ? <ChevronRight size={24} color="#111827" /> : <ChevronLeft size={24} color="#111827" />}
        </Pressable>
  <Text className="text-h3 font-bold text-gray-900 flex text-center">{t('profile.securityAndPrivacy', 'Security & Privacy')}</Text>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="mx-3 mt-4 rounded-2xl bg-white overflow-hidden">
          {/* Section header: الأمان */}
          <View className="px-5 pt-4 pb-2">
            <Text className="text-h4 font-medium text-gray-700" style={{ textAlign: isRTL ? 'right' : 'left' }}>{t('profile.securityTitle', 'Security')}</Text>
          </View>


          <View className="px-5 py-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', flex: 1 }}>
              <View style={{
                width: 30,
                height: 30,

                marginLeft: isRTL ? 8 : 0,
                marginRight: isRTL ? 0 : 8,
              }}>
                <ScanFace color={'#6D28D9'} height={24} width={24} />
              </View>

              <View style={{ flex: 1 }}>
                  <Text className="text-body font-medium text-gray-900" style={{ textAlign: isRTL ? 'right' : 'left' }}>{t('profile.appSecurity', 'App Security')}</Text>
                <Text className="text-body-sm text-gray-500 mt-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>{t('profile.appSecurityStatus', 'Status: On')}</Text>
              </View>
            </View>

            <Switch value={appSecurityEnabled} onValueChange={setAppSecurityEnabled} trackColor={{ false: '#E5E7EB', true: '#10B981' }} thumbColor="#FFFFFF" />
          </View>

          <View className="h-[1px] bg-neutral-200" />

          {/* Navigation rows */}
          <Pressable onPress={() => onNavigate?.('profile-logout-confirm')}>
            <View className="px-5 py-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', flex: 1 }}>
                <View style={{ width: 30 ,marginRight: isRTL ? 0 : 8 , marginLeft: isRTL ? 8 : 0 }}>
                  <LogOut size={24} color="#6D28D9" />   
                               </View>
                <View style={{ flex: 1 }}>
                  <Text className="text-body font-medium text-gray-900" style={{ textAlign: isRTL ? 'right' : 'left' }}>{t('profile.logoutAllDevices', 'Log out from all devices')}</Text>
                  <Text className="text-body-xs  text-gray-500 mt-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>{t('profile.logoutAllDevicesDesc', 'If any sessions are active, sign out from all devices')}</Text>
                </View>
              </View>

              {/* chevron for navigation */}
              {isRTL ? <ChevronLeft size={20} color="#111827" /> : <ChevronRight size={20} color="#111827" />}
            </View>
          </Pressable>


          <Pressable onPress={() => onNavigate?.('profile-delete-confirm')}>
            <View className="px-5 py-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', flex: 1 }}>
                 <View style={{ width: 30 ,marginRight: isRTL ? 0 : 8 , marginLeft: isRTL ? 8 : 0 }}>
                  <CircleOff size={24} color="#6D28D9" />
                 </View>
                <View style={{ flex: 1 }}>
                  <Text className="text-body font-medium text-gray-900" style={{ textAlign: isRTL ? 'right' : 'left' }}>{t('profile.deleteAccount', 'Delete Account')}</Text>
                </View> 
              </View>

              {isRTL ? <ChevronLeft size={20} color="#111827" /> : <ChevronRight size={20} color="#111827" />}
            </View>
          </Pressable>


          


          <Pressable>
            <View className="px-5 py-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', flex: 1 }}>
                
                
                <View style={{ flex: 1 }}>
                  <Text className="text-body font-medium text-gray-900" style={{ textAlign: isRTL ? 'right' : 'left' }}>{t('profile.privacyPolicy', 'Privacy Policy')}</Text>
                </View>
              </View>

              {isRTL ? <ChevronLeft size={20} color="#111827" /> : <ChevronRight size={20} color="#111827" />}
            </View>
          </Pressable>

        </View>
      </ScrollView>
        <ConfirmModal
        visible={showDeleteModal}
        type="delete"
        onClose={() => setShowDeleteModal(false)}
        onConfirm={() => {
          setShowDeleteModal(false);
          onNavigate?.('profile-delete-confirm');
        }}
      />
    </View>
  );
};

export default SecurityScreen;
