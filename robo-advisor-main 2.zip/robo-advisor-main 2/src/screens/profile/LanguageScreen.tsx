import React from 'react';
import { View, ScrollView, Pressable } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, ChevronRight, Check } from 'lucide-react-native';

interface LanguageScreenProps {
  onBack?: () => void;
}

export const LanguageScreen: React.FC<LanguageScreenProps> = ({ onBack }) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  const currentLang = i18n.language;

  const languages = [
    { code: 'ar', name: 'العربية', nameEn: 'Arabic' },
    { code: 'en', name: 'English', nameEn: 'English' },
  ];

  const handleLanguageChange = (langCode: string) => {
    i18n.changeLanguage(langCode);
  };

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center px-5 pt-4 pb-2`}>
        <Pressable onPress={onBack} hitSlop={10} className="p-2">
          {isRTL ? (
            <ChevronRight size={24} color="#111827" />
          ) : (
            <ChevronLeft size={24} color="#111827" />
          )}
        </Pressable>
        <Text className="text-h3 font-bold text-gray-900 flex-1 text-center">
          {t('profile.language')}
        </Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="mx-5 mt-4 rounded-2xl bg-white border border-neutral-200 overflow-hidden">
          {languages.map((lang, index) => (
            <React.Fragment key={lang.code}>
              {index > 0 && <View className="h-[1px] bg-neutral-200 mx-5" />}
              <Pressable
                className="px-5 py-4 active:bg-neutral-50"
                onPress={() => handleLanguageChange(lang.code)}
              >
                <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between`}>
                  <Text className={`text-body font-medium text-gray-900 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {lang.name}
                  </Text>
                  {currentLang === lang.code && (
                    <Check size={20} color="#10B981" strokeWidth={3} />
                  )}
                </View>
              </Pressable>
            </React.Fragment>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};
