import React, { useState } from 'react';
import { View, ScrollView, Pressable } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { 
  ChevronLeft, 
  ChevronRight, 
  Bell, 
  Settings, 
  Wallet, 
  Shield, 
  Info
} from 'lucide-react-native';
import { BottomNavigation } from '../home/components/BottomNavigation';
import { ConfirmModal } from './components/ConfirmModal';
import { PinModal } from './components/PinModal';
import { NavigationState } from '@/navigation/RootNavigator';

interface ProfileScreenProps {
  onNavigate?: (screen: NavigationState) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({ onNavigate }) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showPinModal, setShowPinModal] = useState(false);

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <View className="bg-white px-5 pt-4 pb-4">
        <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between mb-4`}>
          <Text className={`text-h2 font-bold text-gray-900 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t('profile.accountTitle')}
          </Text>
         
        </View>
        
        {/* User Info */}
        <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between`}>
        
          <View className={`flex-1 ${isRTL ? 'items-end' : 'items-start'}`}>
            <Text className={`text-body font-semibold text-gray-900 ${isRTL ? 'text-right' : 'text-left'}`}>
              {t('profile.userName')}
            </Text>
            <Text className={`text-body-sm text-gray-500 ${isRTL ? 'text-right' : 'text-left'}`}>
              {t('profile.userEmail')}
            </Text>
          </View>
           <Pressable onPress={() => onNavigate?.('profile-edit')}>
            <Text className="text-body text-violet-600 font-medium">
              {t('profile.edit')}
            </Text>
          </Pressable>

        </View>
      </View>

      <ScrollView 
        className="flex-1" 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
      >
      

        {/* Menu Items */}
        <View className="bg-white mt-4">
          {/* Notifications */}
          <Pressable
            className="px-5 py-4 active:bg-neutral-50 border-b border-neutral-100"
            onPress={() => onNavigate?.('profile-notifications')}
          >
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between`}>
              <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center flex-1`}>
                <View className={`w-14 h-14 rounded-full bg-primary-600 items-center justify-center ${isRTL ? 'ml-3' : 'mr-3'}`}>
                  <Bell size={24} color="white" />
                </View>
                <Text className={`text-body-lg font-semibold text-black ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t('profile.notifications')}
                </Text>
              </View>
              {isRTL ? (
                <ChevronLeft size={20} color="black" />
              ) : (
                <ChevronRight size={20} color="black" />
              )}
            </View>
          </Pressable>

          {/* Settings */}
          <Pressable
            className="px-5 py-4 active:bg-neutral-50 border-b border-neutral-100"
            onPress={() => onNavigate?.('profile-settings')}
          >
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between`}>
              <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center flex-1`}>
                <View className={`w-14 h-14 rounded-full bg-primary-600 items-center justify-center ${isRTL ? 'ml-3' : 'mr-3'}`}>
                  <Settings size={24} color="white" />
                </View>
                <Text className={`text-body-lg font-semibold text-black ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t('profile.settings')}
                </Text>
              </View>
              {isRTL ? (
                <ChevronLeft size={20} color="black" />
              ) : (
                <ChevronRight size={20} color="black" />
              )}
            </View>
          </Pressable>

          {/* Accounts */}
          <Pressable
            className="px-5 py-4 active:bg-neutral-50 border-b border-neutral-100"
            onPress={() => onNavigate?.('profile-accounts')}
          >
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between`}>
              <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center flex-1`}>
                <View className={`w-14 h-14 rounded-full bg-primary-600 items-center justify-center ${isRTL ? 'ml-3' : 'mr-3'}`}>
                  <Wallet size={24} color="white" />
                </View>
                <Text className={`text-body-lg font-semibold text-black ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t('profile.accounts')}
                </Text>
              </View>
              {isRTL ? (
                <ChevronLeft size={20} color="black" />
              ) : (
                <ChevronRight size={20} color="black" />
              )}
            </View>
          </Pressable>

          {/* Security & Privacy */}
          <Pressable
            className="px-5 py-4 active:bg-neutral-50 border-b border-neutral-100"
            onPress={() => onNavigate?.('profile-security')}
          >
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between`}>
              <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center flex-1`}>
                <View className={`w-14 h-14 rounded-full bg-primary-600 items-center justify-center ${isRTL ? 'ml-3' : 'mr-3'}`}>
                  <Shield size={24} color="white" />
                </View>
                <Text className={`text-body-lg font-semibold text-black ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t('profile.securityAndPrivacy')}
                </Text>
              </View>
              {isRTL ? (
                <ChevronLeft size={20} color="black " />
              ) : (
                <ChevronRight size={20} color="black" />
              )}
            </View>
          </Pressable>

          {/* About Us */}
          <Pressable
            className="px-5 py-4 active:bg-neutral-50"
          >
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between`}>
              <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center flex-1`}>
                <View className={`w-14 h-14 rounded-full bg-primary-600 items-center justify-center ${isRTL ? 'ml-3' : 'mr-3'}`}>
                  <Info size={24} color="white" />
                </View>
                <Text className={`text-body-lg font-semibold text-black ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t('profile.aboutUs')}
                </Text>
              </View>
              {isRTL ? (
                <ChevronLeft size={20} color="#9CA3AF" />
              ) : (
                <ChevronRight size={20} color="#9CA3AF" />
              )}
            </View>
          </Pressable>
        </View>

       

        {/* Logout Button */}
        <View className="px-5 pt-6 pb-4">
          <Pressable 
            className="py-4 bg-white border border-neutral-200 rounded-xl items-center active:opacity-80"
            onPress={() => setShowLogoutModal(true)}
          >
            <Text className="text-body-lg font-semibold text-red-500">
              {t('profile.logout')}
            </Text>
          </Pressable>
        </View>

        {/* Version & Links */}
        <View className="items-center pb-6 px-5">
          <Text className="text-body-sm text-black mb-2">
            {t('profile.version')}
          </Text>
          <Pressable>
            <Text className="text-body-sm text-violet-600 font-medium">
              {t('profile.privacyPolicyShort')}
            </Text>
          </Pressable>
        </View>
      </ScrollView>

      {/* Bottom Navigation */}
      <BottomNavigation 
        activeTab="account" 
        onTabChange={(tab) => onNavigate?.(tab)} 
      />

      {/* Modals */}
      <ConfirmModal
        visible={showLogoutModal}
        type="logout"
        onClose={() => setShowLogoutModal(false)}
        onConfirm={() => {
          setShowLogoutModal(false);
          // Handle logout logic
        }}
      />
      
      <ConfirmModal
        visible={showDeleteModal}
        type="delete"
        onClose={() => setShowDeleteModal(false)}
        onConfirm={() => {
          setShowDeleteModal(false);
          onNavigate?.('profile-delete-confirm');
        }}
      />

      <PinModal
        visible={showPinModal}
        onClose={() => setShowPinModal(false)}
        onSuccess={() => {
          setShowPinModal(false);
          // Handle account deletion
        }}
        title={t('profile.enterPin')}
      />
    </View>
  );
};
