import React, { useState } from 'react';
import { View, ScrollView, Pressable, Switch } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, ChevronRight } from 'lucide-react-native';

interface NotificationsScreenProps {
  onBack?: () => void;
}

export const NotificationsScreen: React.FC<NotificationsScreenProps> = ({ onBack }) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  
  const [allNotifications, setAllNotifications] = useState(true);
  const [investments, setInvestments] = useState(true);
  const [portfolio, setPortfolio] = useState(false);
  const [conversions, setConversions] = useState(true);
  const [security, setSecurity] = useState(true);

  const notificationSettings = [
    {
      id: 'all',
      title: t('profile.allNotifications'),
      subtitle: t('profile.allNotificationsDesc'),
      value: allNotifications,
      onChange: setAllNotifications,
    },
    {
      id: 'investments',
      title: t('profile.investmentNotifications'),
      subtitle: t('profile.investmentNotificationsDesc'),
      value: investments,
      onChange: setInvestments,
    },
    {
      id: 'portfolio',
      title: t('profile.portfolioNotifications'),
      subtitle: t('profile.portfolioNotificationsDesc'),
      value: portfolio,
      onChange: setPortfolio,
    },
    {
      id: 'conversions',
      title: t('profile.conversionNotifications'),
      subtitle: t('profile.conversionNotificationsDesc'),
      value: conversions,
      onChange: setConversions,
    },
    {
      id: 'security',
      title: t('profile.securityNotifications'),
      subtitle: t('profile.securityNotificationsDesc'),
      value: security,
      onChange: setSecurity,
    },
  ];

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center px-5 pt-4 pb-2`}>
        <Pressable onPress={onBack} hitSlop={10} className="p-2">
          {isRTL ? (
            <ChevronRight size={24} color="#111827" />
          ) : (
            <ChevronLeft size={24} color="#111827" />
          )}
        </Pressable>
        <Text className="text-h3 font-bold text-gray-900 flex-1 text-center">
          {t('profile.notifications')}
        </Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="mx-5 mt-4 rounded-2xl bg-white border border-neutral-200 overflow-hidden">
          {notificationSettings.map((setting, index) => (
            <React.Fragment key={setting.id}>
              {index > 0 && <View className="h-[1px] bg-neutral-200 mx-5" />}
              <View className="px-5 py-4">
                <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between`}>
                  <View className={`flex-1 ${isRTL ? 'ml-4' : 'mr-4'}`}>
                    <Text className={`text-body font-medium text-gray-900 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {setting.title}
                    </Text>
                    <Text className={`text-body-sm text-gray-500 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {setting.subtitle}
                    </Text>
                  </View>
                  <Switch
                    value={setting.value}
                    onValueChange={setting.onChange}
                    trackColor={{ false: '#D1D5DB', true: '#10B981' }}
                    thumbColor="#FFFFFF"
                  />
                </View>
              </View>
            </React.Fragment>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};
