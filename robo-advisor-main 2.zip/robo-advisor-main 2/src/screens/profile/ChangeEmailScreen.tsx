import React from 'react';
import { View, Pressable, TextInput, I18nManager } from 'react-native';
import { Text, Button } from '@/components';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, ChevronRight } from 'lucide-react-native';
import { NavigationState } from '@/navigation/RootNavigator';

interface ChangeEmailScreenProps {
  onBack?: () => void;
  onNavigate?: (email: NavigationState) => void;
}

const ChangeEmailScreen: React.FC<ChangeEmailScreenProps> = ({ onBack, onNavigate }) => {
  const { t, i18n } = useTranslation();
  const isRTL = typeof i18n.dir === 'function' ? i18n.dir(i18n.language) === 'rtl' : I18nManager.isRTL;
  const [email, setEmail] = React.useState('');

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <View className={`px-5  pb-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center`}>
        <Pressable onPress={onBack} hitSlop={10} className="p-2">
          {isRTL ? <ChevronRight size={28} color="#111827" /> : <ChevronLeft size={28} color="#111827" />}
        </Pressable>
        <Text className="text-h2 font-bold text-gray-900 flex text-center">{t('profile.changeEmailTitle')}</Text>
      </View>

      <View className="px-5 pt-6">
        <Text className={`text-body text-gray-600 ${isRTL ? 'text-right' : 'text-left'} mb-4`}>{t('profile.changeEmailSubtitle')}</Text>

        <Text className={`text-sm font-medium text-gray-600 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>{t('profile.changeEmailLabel')}</Text>
        <TextInput
          value={email}
          onChangeText={setEmail}
          className={`${isRTL ? 'text-right' : 'text-left'} rounded-xl border border-neutral-200 px-4 py-4 text-base h-14 mb-6`}
          placeholder={t('profile.changeEmailPlaceholder')}
          keyboardType="email-address"
        />

        <View className="mt-4">
          <Button title={t('profile.changeEmailContinue', 'Continue')} onPress={() =>{ onNavigate?.('account-22')}} />
        </View>
      </View>
    </View>
  );
};

export default ChangeEmailScreen;
