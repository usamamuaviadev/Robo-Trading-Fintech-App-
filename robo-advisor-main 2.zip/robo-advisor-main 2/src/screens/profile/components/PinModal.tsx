import React, { useState } from 'react';
import { View, Modal, Pressable } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { X } from 'lucide-react-native';

interface PinModalProps {
  visible: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  title?: string;
}

export const PinModal: React.FC<PinModalProps> = ({ 
  visible, 
  onClose, 
  onSuccess,
  title 
}) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  const [pin, setPin] = useState('');

  const handleNumberPress = (num: string) => {
    if (pin.length < 4) {
      const newPin = pin + num;
      setPin(newPin);
      
      if (newPin.length === 4) {
        setTimeout(() => {
          onSuccess?.();
          setPin('');
        }, 300);
      }
    }
  };

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
  };

  const handleClose = () => {
    setPin('');
    onClose();
  };

  const numberPad = [
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['7', '8', '9'],
    ['*', '0', '←'],
  ];

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={handleClose}
    >
      <View className="flex-1 bg-black/40">
        <Pressable className="flex-1" onPress={handleClose} />
        
        <View className="bg-white rounded-t-3xl">
          {/* Handle */}
          <View className="items-center justify-center py-3">
            <View className="w-12 h-1 bg-neutral-300 rounded-full" />
          </View>

          {/* Header */}
          <View className="px-5 py-4 border-b border-neutral-200">
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between`}>
              <Text className="text-h4 font-bold text-gray-900">
                {title || t('profile.enterPin')}
              </Text>
              <Pressable onPress={handleClose} hitSlop={10}>
                <X size={24} color="#6B7280" />
              </Pressable>
            </View>
          </View>

          {/* PIN Dots */}
          <View className="px-5 py-8">
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} justify-center gap-4 mb-8`}>
              {[0, 1, 2, 3].map((index) => (
                <View
                  key={index}
                  className={`w-4 h-4 rounded-full ${
                    index < pin.length ? 'bg-violet-600' : 'bg-neutral-200'
                  }`}
                />
              ))}
            </View>

            {/* Number Pad */}
            <View className="gap-4">
              {numberPad.map((row, rowIndex) => (
                <View key={rowIndex} className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} justify-center gap-4`}>
                  {row.map((num) => (
                    <Pressable
                      key={num}
                      className="w-20 h-16 items-center justify-center bg-neutral-100 rounded-xl active:bg-neutral-200"
                      onPress={() => {
                        if (num === '←') handleDelete();
                        else if (num !== '*') handleNumberPress(num);
                      }}
                    >
                      <Text className="text-h3 font-semibold text-gray-900">
                        {num}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              ))}
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};
