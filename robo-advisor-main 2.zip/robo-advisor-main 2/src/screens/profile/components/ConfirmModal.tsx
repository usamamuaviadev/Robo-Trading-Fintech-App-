import React from 'react';
import { View, Modal, Pressable } from 'react-native';
import { Text, Button } from '@/components';
import { useTranslation } from 'react-i18next';
import { X, Trash2, AlertCircle } from 'lucide-react-native';
import Logout from '@/assets/icons/logout.svg';

interface ConfirmModalProps {
  visible: boolean;
  onClose: () => void;
  onConfirm?: () => void;
  type: 'logout' | 'delete';
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({ 
  visible, 
  onClose, 
  onConfirm,
  type 
}) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';

  const config = {
    logout: {
      icon: Logout ,
      iconColor: '#DC2626',
      iconBg: '#FEE2E2',
      title: t('profile.logoutConfirmTitle'),
      description: t('profile.logoutConfirmDesc'),
      confirmText: t('profile.logoutConfirm'),
      cancelText: t('profile.cancel'),
    },
    delete: {
      icon: Trash2,
      iconColor: '#DC2626',
      iconBg: '#FEE2E2',
      title: t('profile.deleteConfirmTitle'),
      description: t('profile.deleteConfirmDesc'),
      confirmText: t('profile.deleteConfirm'),
      cancelText: t('profile.cancel'),
    },
  };

  const currentConfig = config[type];
  const Icon = currentConfig.icon;

  return ( 
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View className="flex-1 bg-black/40 items-center justify-center px-4">
        <View className="bg-white rounded-3xl w-full max-w-sm overflow-hidden  pt-8 items-center">
          {/* Icon */}
          <View className="items-center pt-8 pb-10">
            <View 
              className="w-16 h-16 rounded-full items-center justify-center mb-2"
              style={{ backgroundColor: currentConfig.iconBg }}
            >
              <Icon size={32} color={currentConfig.iconColor} />
            </View>
          </View>

          {/* Content */}
          <View className="w-full items-center">
            <Text className={`text-h2 font-bold text-gray-900 mb-2 text-center`}>
              {currentConfig.title}
            </Text>
            <Text className={`text-body text-gray-600 mb-7 text-center`}>
              {currentConfig.description}
            </Text>

            {/* Actions */}
            <View className="w-full flex-row border-t border-gray-400 gap-0">
               <Pressable
                className="py-4   items-center border-r border-gray-400 active:opacity-90 w-1/2"
                onPress={onClose}
              >
                <Text className="text-body-lg font-semibold text-gray-900">
                  {currentConfig.cancelText}
                </Text>
              </Pressable>
              <Pressable
                className="py-4 items-center  active:opacity-90 w-1/2"
                onPress={onConfirm}
              >
                <Text className="text-body-lg font-semibold text-red-500">
                  {currentConfig.confirmText}
                </Text>
              </Pressable>
             
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};
