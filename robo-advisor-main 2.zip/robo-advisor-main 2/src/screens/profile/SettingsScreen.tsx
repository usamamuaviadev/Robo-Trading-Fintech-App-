import React, { useState, useMemo } from 'react';
import { View, ScrollView, Pressable, Switch, I18nManager } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { Bell, ChevronLeft, ChevronRight, Landmark, Newspaper, Sparkles } from 'lucide-react-native';

interface SettingsScreenProps {
  onBack?: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ onBack }) => {
  const { t, i18n } = useTranslation();
  // Prefer i18n.dir() if available (handles more languages than checking for 'ar')
  const isRTL = typeof i18n.dir === 'function' ? i18n.dir(i18n.language) === 'rtl' : I18nManager.isRTL;
  
  const [notifications, setNotifications] = useState(true);
  const [faceId, setFaceId] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  // per-option toggles shown in the screenshot
  const [bankNotifications, setBankNotifications] = useState(true);
  const [productNotifications, setProductNotifications] = useState(false);
  const [marketingNotifications, setMarketingNotifications] = useState(false);

  // Build the exact items present in the screenshot (Arabic literals)
  const settings = useMemo(
    () => [
      {
        id: 'bank',
        title: t('profile.notificationBankTitle'),
        subtitle: t('profile.notificationBankDesc'),
        value: bankNotifications,
        onChange: setBankNotifications,
        icon : <Landmark size={24} color="#6D28D9" />
      },
      {
        id: 'product',
        title: t('profile.notificationProductTitle'),
        subtitle: t('profile.notificationProductDesc'),
        value: productNotifications,
        onChange: setProductNotifications,
        icon : <Sparkles size={24} color="#6D28D9" />
      },
      {
        id: 'marketing',
        title: t('profile.notificationMarketingTitle'),
        subtitle: t('profile.notificationMarketingDesc'),
        value: marketingNotifications,
        onChange: setMarketingNotifications,
        icon : <Newspaper size={24} color="#6D28D9" />
      },
    ],
    [bankNotifications, productNotifications, marketingNotifications, t]
  );

  return (
    <View className="flex-1  bg-white">
      {/* Header */}
      <View
        className={`flex ${isRTL? 'flex-row-reverse' : ' flex-row justify-start items-center px-5 pt-4 pb-2'}`}
      >
        <Pressable onPress={onBack} hitSlop={10} className="p-2">
          {isRTL ? <ChevronRight size={24} color="#111827" /> : <ChevronLeft size={24} color="#111827" />}
        </Pressable>
        <Text className="text-h3 font-bold text-gray-900text-center">{t('profile.settings') || 'الإعدادات'}</Text>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="mx-5 mt-4 pb-8 rounded-2xl bg-white border-b border-neutral-200 overflow-hidden">
          {/* Top global toggle row */}
          <View className="px-5 py-4">
            <View style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <Text className="text-h4 font-semibold text-gray-900" style={{ textAlign: isRTL ? 'right' : 'left' }}>
                  {t('profile.notificationsDetails') || 'تفعيل جميع الإشعارات'}
                </Text>
          </View>
          </View>


          {/* Bell item row (فعل الإشعارات) shown under the top heading in the screenshot */}
          <Pressable onPress={() => setNotifications(!notifications)}>
            <View className="px-5 py-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'flex-start', flex: 1 }}>
                <View style={{
                  width: 30,
                  height: 30,
                 
                  marginLeft: isRTL ? 8 : 0,
                  marginRight: isRTL ? 0 : 8,
                }}>
                  <Bell size={24} color="#6D28D9" />
                </View>

                <View style={{ flex: 1 }}>
                  <Text className="text-h font-semibold text-gray-900" style={{ textAlign: isRTL ? 'right' : 'left' }}>{t('profile.notificationBellTitle')}</Text>
                  <Text className="text-body-xs text-gray-500 mt-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>{t('profile.notificationBellDesc')}</Text>
                </View>
              </View>

              <Switch value={notifications} onValueChange={setNotifications} trackColor={{ false: '#E5E7EB', true: '#10B981' }} thumbColor="#FFFFFF" />
            </View>
          </Pressable>

          <View className="h-[1px] bg-neutral-200" />

          {/* Section header */}
          <View className="px-5 flex-row justify-end py-3">
            <Text className="text-h4 font-semibold text-gray-700">{t('profile.notifications')}</Text>
          </View>


          {/* Options list */}
          {settings.map((setting, index) => (
            <Pressable key={setting.id} onPress={() => setting.onChange(!setting.value)}>
              <View className="px-5 py-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <View style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'flex-start', flex: 1 }}>
                  {/* Icon placeholder */}
                  <View style={{
                    width: 30,
                    height: 30  ,
                    
                    marginLeft: isRTL ? 8 : 0,
                    marginRight: isRTL ? 0 : 8,
                  }}>
                    {setting.icon}
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text className="text-body font-semibold text-gray-900" style={{ textAlign: isRTL ? 'right' : 'left' }}>{setting.title}</Text>
                    <Text className="text-body-xs text-gray-500 mt-1" style={{ textAlign: isRTL ? 'right' : 'left' }}>{setting.subtitle}</Text>
                  </View>
                </View>

                <Switch value={setting.value} onValueChange={setting.onChange} trackColor={{ false: '#E5E7EB', true: '#10B981' }} thumbColor="#FFFFFF" />
              </View>
              {/* divider except last */}
              {index < settings.length - 1 && <View className="h-[1px] bg-neutral-200" />}
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};
