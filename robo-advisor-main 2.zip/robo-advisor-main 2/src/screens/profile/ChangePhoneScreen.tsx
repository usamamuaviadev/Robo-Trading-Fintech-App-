import React, { useState } from 'react';
import { View, ScrollView, Pressable, TextInput } from 'react-native';
import { Text, Button } from '@/components';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, ChevronRight } from 'lucide-react-native';

interface ChangePhoneScreenProps {
  onBack?: () => void;
  onNavigate?: (screen: 'profile-verify-phone') => void;
}

export const ChangePhoneScreen: React.FC<ChangePhoneScreenProps> = ({ onBack, onNavigate }) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  const [phoneNumber, setPhoneNumber] = useState('');

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center px-5 pt-4 pb-2`}>
        <Pressable onPress={onBack} hitSlop={10} className="p-2">
          {isRTL ? (
            <ChevronRight size={24} color="#111827" />
          ) : (
            <ChevronLeft size={24} color="#111827" />
          )}
        </Pressable>
        <Text className="text-h3 font-bold text-gray-900 flex-1 text-center">
          {t('profile.changePhoneTitle')}
        </Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView className="flex-1 px-5" showsVerticalScrollIndicator={false}>
        <View className="mt-6">
          <Text className={`text-body text-gray-600 mb-6 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t('profile.changePhoneSubtitle')}
          </Text>

          <View className="mb-6">
            <Text className={`text-body-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
              {t('profile.newPhoneNumber')}
            </Text>
            <TextInput
              className={`border border-neutral-300 rounded-xl px-4 py-3 text-body ${isRTL ? 'text-right' : 'text-left'}`}
              placeholder="5XXXXXXXX"
              value={phoneNumber}
              onChangeText={setPhoneNumber}
              keyboardType="phone-pad"
              textAlign={isRTL ? 'right' : 'left'}
            />
          </View>
        </View>
      </ScrollView>

      <View className="px-5 pb-6">
        <Button
          title={t('profile.sendVerificationCode')}
          onPress={() => onNavigate?.('profile-verify-phone')}
        />
      </View>
    </View>
  );
};
