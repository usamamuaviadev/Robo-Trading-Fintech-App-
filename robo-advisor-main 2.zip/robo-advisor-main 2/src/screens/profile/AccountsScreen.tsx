import React from 'react';
import { View, ScrollView, Pressable, I18nManager } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, ChevronRight } from 'lucide-react-native';

interface AccountsScreenProps {
  onBack?: () => void;
}

const AccountsScreen: React.FC<AccountsScreenProps> = ({ onBack }) => {
  const { t, i18n } = useTranslation();
  const isRTL = typeof i18n.dir === 'function' ? i18n.dir(i18n.language) === 'rtl' : I18nManager.isRTL;

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <View className="items-center px-5 pt-4 pb-2" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', alignItems: 'center' }}>
        <Pressable onPress={onBack} hitSlop={10} className="p-2">
          {isRTL ? <ChevronRight size={24} color="#111827" /> : <ChevronLeft size={24} color="#111827" />}
        </Pressable>
        <Text className="text-h3 font-bold text-gray-900 flex text-right">{t('profile.accounts', 'Accounts')}</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
        <View className="mx-5 mt-6">
          {/* Section title */}
          <View className="px-2 mb-4">
            <Text className="text-h4 font-semibold text-gray-900" style={{ textAlign: isRTL ? 'right' : 'left' }}>{t('profile.currentAccount', 'Current account')}</Text>
          </View>

          {/* Account details block */}
          <View className="px-2">
            <View style={{ alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
              <Text className="text-xs font-medium text-gray-500">{t('profile.iban', 'IBAN')}</Text>
              <Text className="text-body font-semibold text-gray-900 mt-2">{t('profile.ibanValue', '15464645614')}</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default AccountsScreen;

