import React, { useState, useRef, useEffect } from 'react';
import { View, TextInput, Pressable } from 'react-native';
import { Text, Button } from '@/components';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, ChevronRight } from 'lucide-react-native';

interface VerifyPhoneScreenProps {
  onBack?: () => void;
  onSuccess?: () => void;
}

export const VerifyPhoneScreen: React.FC<VerifyPhoneScreenProps> = ({ onBack, onSuccess }) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const inputRefs = useRef<(TextInput | null)[]>([]);

  const handleCodeChange = (text: string, index: number) => {
    const newCode = [...code];
    newCode[index] = text;
    setCode(newCode);

    if (text && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyPress = (e: any, index: number) => {
    if (e.nativeEvent.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center px-5 pt-4 pb-2`}>
        <Pressable onPress={onBack} hitSlop={10} className="p-2">
          {isRTL ? (
            <ChevronRight size={24} color="#111827" />
          ) : (
            <ChevronLeft size={24} color="#111827" />
          )}
        </Pressable>
        <Text className="text-h3 font-bold text-gray-900 flex-1 text-center">
          {t('profile.verifyPhone')}
        </Text>
        <View style={{ width: 40 }} />
      </View>

      <View className="flex-1 px-5 pt-6">
        <Text className={`text-body text-gray-600 mb-8 ${isRTL ? 'text-right' : 'text-left'}`}>
          {t('createAccount.step14.subtitle')}
        </Text>

        {/* OTP Input */}
        <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} justify-between mb-8`}>
          {code.map((digit, index) => (
            <TextInput
              key={index}
              ref={(ref) => { inputRefs.current[index] = ref; }}
              className="w-12 h-14 border-2 border-neutral-300 rounded-xl text-center text-h4 font-bold"
              value={digit}
              onChangeText={(text) => handleCodeChange(text, index)}
              onKeyPress={(e) => handleKeyPress(e, index)}
              keyboardType="number-pad"
              maxLength={1}
              selectTextOnFocus
            />
          ))}
        </View>

        <View className="items-center">
          <Text className="text-body-sm text-gray-500">
            {t('createAccount.step14.notReceived')}{' '}
            <Text className="text-violet-600 font-semibold">
              {t('createAccount.step14.resend')}
            </Text>
          </Text>
        </View>
      </View>

      <View className="px-5 pb-6">
        <Button
          title={t('createAccount.step14.verify')}
          onPress={() => onSuccess?.()}
        />
      </View>
    </View>
  );
};
