import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, Pressable } from 'react-native';
import { Button, Card, Badge, BottomSheet } from '../components';
import { useBottomSheet } from '../hooks';
import { useTranslation } from 'react-i18next';

interface PortfolioScreenProps {
  testID?: string;
}

interface Investment {
  id: string;
  name: string;
  symbol: string;
  amount: number;
  shares: number;
  currentPrice: number;
  return: number;
  returnPercent: number;
}

export const PortfolioScreen: React.FC<PortfolioScreenProps> = ({ testID }) => {
  const { t } = useTranslation();
  const { visible: filterVisible, open: openFilter, close: closeFilter } = useBottomSheet();
  const [searchText, setSearchText] = useState('');

  const investments: Investment[] = [
    {
      id: '1',
      name: 'Apple Inc',
      symbol: 'AAPL',
      amount: 5000,
      shares: 25,
      currentPrice: 200,
      return: 500,
      returnPercent: 10,
    },
    {
      id: '2',
      name: 'Microsoft Corp',
      symbol: 'MSFT',
      amount: 4000,
      shares: 15,
      currentPrice: 266.67,
      return: 600,
      returnPercent: 15,
    },
    {
      id: '3',
      name: 'Amazon.com Inc',
      symbol: 'AMZN',
      amount: 3500,
      shares: 10,
      currentPrice: 350,
      return: 200,
      returnPercent: 5.7,
    },
  ];

  const filteredInvestments = investments.filter(inv =>
    inv.name.toLowerCase().includes(searchText.toLowerCase()) ||
    inv.symbol.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <View className="flex-1 bg-neutral-50" testID={testID}>
      {/* Header */}
      <View className="bg-white px-lg py-md border-b border-neutral-200">
        <Text className="text-h4 font-bold text-gray-900 mb-4">
          {t('portfolio.myPortfolio')}
        </Text>

        {/* Search Bar */}
        <View className="flex flex-row gap-md items-center">
          <View className="flex-1 bg-neutral-100 rounded-md px-md py-sm flex flex-row items-center">
            <TextInput
              placeholder={t('portfolio.search')}
              value={searchText}
              onChangeText={setSearchText}
              className="flex-1 text-body text-gray-900"
              placeholderTextColor="#999"
            />
          </View>
          <Pressable
            className="bg-primary-500 w-10 h-10 rounded-md items-center justify-center"
            onPress={openFilter}
          >
            <Text className="text-lg">⚙️</Text>
          </Pressable>
        </View>
      </View>

      {/* Portfolio Stats */}
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="px-lg py-lg gap-lg">
          {/* Total Summary */}
          <Card variant="elevated">
            <View className="items-center">
              <Text className="text-caption text-gray-600 mb-2">
                {t('portfolio.totalInvested')}
              </Text>
              <Text className="text-h3 font-bold text-gray-900 mb-4">
                $12,500
              </Text>
              <View className="w-full bg-neutral-200 h-1 rounded-full mb-3" />
              <View className="flex flex-row justify-between w-full">
                <View className="items-center">
                  <Text className="text-caption text-gray-600">
                    {t('portfolio.gain')}
                  </Text>
                  <Text className="text-label font-bold text-success-600">
                    +$1,300
                  </Text>
                </View>
                <View className="items-center">
                  <Text className="text-caption text-gray-600">
                    {t('portfolio.gainPercent')}
                  </Text>
                  <Text className="text-label font-bold text-success-600">
                    +10.4%
                  </Text>
                </View>
              </View>
            </View>
          </Card>

          {/* Holdings List */}
          <View className="gap-md">
            <Text className="text-h5 font-bold text-gray-900">
              {t('portfolio.holdings')} ({filteredInvestments.length})
            </Text>

            {filteredInvestments.map((investment) => (
              <Pressable
                key={investment.id}
                className="active:opacity-70"
              >
                <Card variant="bordered">
                  <View className="flex flex-row justify-between items-start mb-3">
                    <View className="flex-1">
                      <Text className="text-label font-bold text-gray-900 mb-1">
                        {investment.name}
                      </Text>
                      <Text className="text-caption text-gray-600">
                        {investment.shares} shares @ ${investment.currentPrice}
                      </Text>
                    </View>
                    <Badge
                      label={`+${investment.returnPercent}%`}
                      variant="success"
                      size="sm"
                    />
                  </View>

                  <View className="flex flex-row justify-between items-center pt-md border-t border-neutral-200">
                    <View>
                      <Text className="text-caption text-gray-600 mb-1">
                        {t('portfolio.invested')}
                      </Text>
                      <Text className="text-h6 font-bold text-gray-900">
                        ${investment.amount}
                      </Text>
                    </View>
                    <View className="items-end">
                      <Text className="text-caption text-gray-600 mb-1">
                        {t('portfolio.currentValue')}
                      </Text>
                      <Text className="text-h6 font-bold text-success-600">
                        ${investment.amount + investment.return}
                      </Text>
                    </View>
                  </View>
                </Card>
              </Pressable>
            ))}
          </View>

          {/* Empty State */}
          {filteredInvestments.length === 0 && (
            <View className="items-center py-12">
              <Text className="text-body text-gray-600 text-center mb-4">
                {t('portfolio.noResults')}
              </Text>
              <Button
                title={t('portfolio.clearSearch')}
                onPress={() => setSearchText('')}
                variant="ghost"
              />
            </View>
          )}

          {/* Add Investment Button */}
          <Button
            title={t('portfolio.addInvestment')}
            onPress={() => {}}
            variant="primary"
            size="lg"
            style={{ marginTop: 12 }}
          />
        </View>
      </ScrollView>

      {/* Filter Bottom Sheet */}
      <BottomSheet
        visible={filterVisible}
        onClose={closeFilter}
        title={t('portfolio.filterOptions')}
        height={300}
      >
        <View className="gap-md">
          <Pressable className="active:bg-neutral-100 p-md rounded-md">
            <Text className="text-body text-gray-900 font-medium">
              {t('portfolio.sortByReturn')}
            </Text>
          </Pressable>
          <Pressable className="active:bg-neutral-100 p-md rounded-md">
            <Text className="text-body text-gray-900 font-medium">
              {t('portfolio.sortByValue')}
            </Text>
          </Pressable>
          <Pressable className="active:bg-neutral-100 p-md rounded-md">
            <Text className="text-body text-gray-900 font-medium">
              {t('portfolio.sortByName')}
            </Text>
          </Pressable>
          <Button
            title={t('portfolio.done')}
            onPress={closeFilter}
            variant="primary"
            style={{ marginTop: 8 }}
          />
        </View>
      </BottomSheet>
    </View>
  );
};
