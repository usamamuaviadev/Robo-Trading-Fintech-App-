import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { TrendingUp, Plus, ArrowUpRight } from 'lucide-react-native';

interface ConversionsListProps {
  activeTab: 'all' | 'deposit' | 'receive' | 'transfer';
  onSelectConversion: (conversion: any) => void;
}

export const ConversionsList: React.FC<ConversionsListProps> = ({ activeTab, onSelectConversion }) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';

  const conversions = [
    {
      id: '1',
      type: 'receive',
      title: t('conversions.receiveTitle'),
      description: t('conversions.receiveDesc'),
      amount: '2400.00',
      status: t('conversions.waiting'),
      date: 'سبتمبر 2025',
      company: 'البنك راجحي',
      method: 'فريق',
      submissionDate: '17 أبريل 2024، 12:26 م',
      icon: 'up',
      color: '#7C3AED',
    },
    {
      id: '2',
      type: 'receive',
      title: t('conversions.receiveTitle'),
      description: t('conversions.receiveDesc'),
      amount: '2400.00',
      status: t('conversions.waiting'),
      date: 'سبتمبر 2025',
      company: 'البنك راجحي',
      method: 'فريق',
      submissionDate: '17 أبريل 2024، 12:26 م',
      icon: 'up',
      color: '#7C3AED',
    },
    {
      id: '3',
      type: 'deposit',
      title: t('conversions.depositTitle'),
      description: t('conversions.depositDesc'),
      amount: '2400.00',
      status: t('conversions.waiting'),
      date: 'سبتمبر 2025',
      company: 'البنك راجحي',
      method: 'فريق',
      submissionDate: '17 أبريل 2024، 12:26 م',
      icon: 'down',
      color: '#7C3AED',
    },
  ];

  const filteredConversions = activeTab === 'all' 
    ? conversions 
    : conversions.filter(c => c.type === activeTab);

  return (
    <View className="px-5 mx-5">
      {/* Date Section */}
      <Text className={`text-body font-semibold text-gray-900 mb-3 ${isRTL ? 'text-right' : 'text-left'}`}>
        سبتمبر 2025
      </Text>

      {/* Conversions List */}
      <View className="gap-3">
        {filteredConversions.map((item) => (
          <Pressable
            key={item.id}
            onPress={() => onSelectConversion(item)}
            className="bg-white rounded-2xl border border-neutral-200 p-4"
          >
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between`}>
              {/* Left Side: Icon + Info */}
              <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center flex-1`}>
                <View 
                  className={`w-10 h-10 rounded-lg items-center justify-center ${isRTL ? 'ml-3' : 'mr-3'}`}
                  style={{ backgroundColor: `${item.color}20` }}
                >
                 {item.type !== 'deposit' ? <ArrowUpRight size={20} color={item.color} /> : <Plus size={20} color={item.color} />}
                </View>
                <View className="flex-1">
                  <Text className={`text-body font-semibold text-gray-900 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {item.title}
                  </Text>
                  <Text className={`text-body-sm text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {item.description}
                  </Text>
                </View>
              </View>

              {/* Right Side: Amount + Status */}
              <View className={isRTL ? 'items-start ml-3' : 'items-end mr-0'}>
                <Text className="text-body font-bold text-gray-900 mb-1" riyal>
                  {item.amount}
                </Text>
                <Text className="text-body-sm text-gray-500">{item.status}</Text>
              </View>
            </View>
          </Pressable>
        ))}
      </View>
    </View>
  );
};
