import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { TrendingUp, ChevronRight, ArrowUp, Plus, Zap } from 'lucide-react-native';

export const ConversionsSection: React.FC = () => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';

  const conversions = [
    {
      id: 'receive',
      title: t('home.receive'),
      description: t('home.receiveDesc'),
      amount: '2400.00',
      status: t('home.waiting'),
    },
    {
      id: 'deposit',
      title: t('home.deposit'),
      description: t('home.depositDesc'),
      amount: '2400.00',
      status: t('home.waiting'),
    },
  ];

  return (
    <View className="mb-6 mx-4 border border-gray-900/20 rounded-2xl py-4">
      {/* Section Header */}
      <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between px-5 mb-3`}>
        <View className={`flex flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} gap-2`} >
            <Zap size={30} color="rgba(124, 58, 237, 1)" />
  <Text className="text-h4 font-bold text-gray-900">
          {t('home.conversions')}
        </Text>
        </View>
      
        <Pressable className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center`}>
          <Text className="text-body text-primary-800 font-medium">
            {t('home.viewMore')}
          </Text>
          {isRTL ? (
            <ChevronRight size={20} color="#7C3AED" style={{ transform: [{ rotate: '180deg' }] }} />
          ) : (
            <ChevronRight size={20} color="#7C3AED" />
          )}
        </Pressable>
      </View>

      {/* Conversion Items */}
      <View className="px-5">
        {conversions.map((item,index) => (
          <Pressable
            key={item.id}
            className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between py-4 `}
          >
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center flex-1`}>
              <View className={`w-12 h-12 rounded-md bg-purple-50 items-center justify-center ${isRTL ? 'ml-3' : 'mr-3'}`}>
                {index < 1 ? <ArrowUp size={20} color="#7C3AED" /> : <Plus size={20} color="#7C3AED" />}
              </View>
              <View className={`flex-1 b ${isRTL ? 'items-end' : ' items-start'}`}>
                <Text className={`text-body-lg font-semibold text-gray-900 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {item.title}
                </Text>
                <Text className={`text-body-xs w-3/4 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {item.description}
                </Text>
              </View>
            </View>
            <View className={isRTL ? 'items-end' : 'items-start'}>
              <Text riyal={true} riyalColor='gray' className="text-body font-bold text-gray-500 mb-1">
                {item.amount}
              </Text>
              <Text className="text-body-sm font-bold text-gray-900">{item.status}</Text>
            </View>
          </Pressable>
        ))}
      </View>
    </View>
  );
};
