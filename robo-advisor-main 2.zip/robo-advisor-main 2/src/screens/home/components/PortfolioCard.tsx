import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { TrendingUp } from 'lucide-react-native';

export const PortfolioCard: React.FC = () => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';

  return (
    <View className="bg-primary-800 rounded-2xl p-5">
      {/* Header Row */}
      <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between mb-4`}>
        <Text className="text-body-lg font-semibold text-white opacity-90">
          {t('home.portfolioValue')}
        </Text>
        <Pressable className="px-3 py-1 bg-white rounded-sm">
          <Text className="text-body-sm text-primary-800 font-medium">
            {t('home.details')}
          </Text>
        </Pressable>
      </View>

      {/* Portfolio Value */}
      <Text riyal={true} riyalSize={40} riyalClass={`justify-${!isRTL ? 'start' : 'end'}`} className={`text-h1 ${isRTL ? 'text-right' : 'text-left'} font-bold text-white mb-2`}>
        0.00
      </Text>

      {/* Return Info */}
      <View className={`flex-row gap-2 ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center`}>
        <TrendingUp size={16} color="#10B981" />
        <Text riyal={true} riyalSize={20}  className='text-white'>0.00</Text>
        <Text className={`text-body-sm text-white ${isRTL ? 'mr-2' : 'ml-2'}`}>
          {t('home.returnInfo')}
        </Text>
      </View>
    </View>
  );
};
