import React, { useState } from 'react';
import { View, ScrollView, Pressable } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { Bell } from 'lucide-react-native';
import { PortfolioCard } from './components/PortfolioCard';
import { InvestmentsSection } from './components/InvestmentsSection';
import { ConversionsSection } from './components/ConversionsSection';
import { CalculatorCard } from './components/CalculatorCard';
import { AccountsSection } from './components/AccountsSection';
import { BottomNavigation } from './components/BottomNavigation';
import { NotificationsBottomSheet } from './components/NotificationsBottomSheet';
import { ProfileHeader } from '@/components/ProfileHeader';

interface HomeScreenProps {
  onNavigate?: (screen: 'home' | 'portfolio' | 'conversions' | 'account') => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onNavigate }) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <ProfileHeader />

      {/* Main Content */}
      <ScrollView 
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
      >
        {/* Portfolio Card */}
        <View className="px-5 mb-4">
          <PortfolioCard />
        </View>

        {/* Investments Section */}
        <InvestmentsSection />

        {/* Conversions Section */}
        <ConversionsSection />

        {/* Calculator Card */}
        <View className="px-5 mb-4">
          <CalculatorCard />
        </View>

        {/* Accounts Section */}
        <AccountsSection />
      </ScrollView>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab="home" onTabChange={onNavigate} />

      {/* Notifications Bottom Sheet */}
      <NotificationsBottomSheet
        visible={showNotifications}
        onClose={() => setShowNotifications(false)}
      />
    </View>
  );
};
