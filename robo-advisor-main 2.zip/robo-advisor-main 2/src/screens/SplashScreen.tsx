import React from 'react';
import { View, Image } from 'react-native';
import { Button } from '../components/Button';
import { useTranslation } from 'react-i18next';
import { colors } from '../utils/designTokens';
import { Text } from '@/components';

interface SplashScreenProps {
  onNext?: () => void;}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onNext }) => {
  const { t } = useTranslation();
  return (
    <View
      className="flex-1 bg-white items-center justify-between py-0 px-lg"
    >
  
      {/* Logo & Title Area */}
      <View className="flex-1 items-center justify-center">
        <View className="w-48 h-48  rounded-3xl items-center justify-center mb-8 ">
          <Text className='text-h1'>LOGO</Text>
        </View>
        <Text className="text-gray-900 text-h1 mb-4 text-center">
          {t('welcome')}
        </Text>
        <Text className="text-lg px-4 text-center">
          {t('onboarding.description4')}
        </Text>
      </View>

      {/* Navigation Dots */}
   

      {/* Button */}
        <Button
          title={t('getStarted')}
          onPress={onNext || (() => {})}
          variant="primary"
          size="lg"
          style={{ width: '100%' }}
        />
        <Button
          title={t('login')}
          onPress={onNext || (() => {})}
          variant="ghost"
          size="lg"
          style={{ width: '100%' }}
        />
           <View className="flex flex-row gap-2 my-2">
        <View className="w-2 h-2 bg-primary-500 rounded-full" />
        <View className="w-2 h-2 bg-primary-300 rounded-full" />
        <View className="w-2 h-2 bg-primary-300 rounded-full" />
        <View className="w-2 h-2 bg-primary-300 rounded-full" />
      </View>
    </View>
  );
};
