import React, { useState } from 'react';
import { View, ScrollView, Pressable } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { Bell } from 'lucide-react-native';
import { AllocationChart } from './components/AllocationChart';
import { FundsSection } from './components/FundsSection';
import { InvestmentPortfoliosSection } from './components/InvestmentPortfoliosSection';
import { BottomNavigation } from '../home/components/BottomNavigation';
import { NotificationsBottomSheet } from '../home/components/NotificationsBottomSheet';
import { ProfileHeader } from '@/components/ProfileHeader';

interface PortfolioScreenProps {
  onNavigate?: (screen: 'home' | 'portfolio' | 'portfolio-details' | 'conversions' | 'account') => void;
}

export const PortfolioScreen: React.FC<PortfolioScreenProps> = ({ onNavigate }) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <View className="flex-1 bg-white">
        <ProfileHeader />
      {/* Header */}

      {/* Main Content */}
      <ScrollView 
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
      >
        <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between px-5 pt-3 pb-4`}>
        <Text className="text-h1 font-bold text-gray-900">
          {t('portfolio.title')}
        </Text>
        
      </View>

        {/* Allocation Distribution & Details */}
        <AllocationChart />

        {/* Funds Section */}

        {/* Investment Portfolios Section */}
        <InvestmentPortfoliosSection onOpen={() => onNavigate?.('portfolio-details')} />
      </ScrollView>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab="portfolio" onTabChange={onNavigate} />

      {/* Notifications Bottom Sheet */}
      <NotificationsBottomSheet
        visible={showNotifications}
        onClose={() => setShowNotifications(false)}
      />
    </View>
  );
};
