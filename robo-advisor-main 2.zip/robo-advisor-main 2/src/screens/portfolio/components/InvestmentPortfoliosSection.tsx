import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { TrendingUp } from 'lucide-react-native';

interface Portfolio {
  id: string;
  title: string;
  amount: string;
  change: string;
  barColor: string;
}

interface InvestmentPortfoliosSectionProps {
  onOpen?: (id: string) => void;
}

export const InvestmentPortfoliosSection: React.FC<InvestmentPortfoliosSectionProps> = ({ onOpen }) => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';

  const portfolios: Portfolio[] = [
    {
      id: 'retirement',
      title: t('portfolio.retirementPortfolio'),
      amount: '26.00',
      change: '%12.50',
      barColor: '#10B981',
    },
    {
      id: 'balanced',
      title: t('portfolio.balancedPortfolioItem'),
      amount: '26.00',
      change: '%12.50',
      barColor: '#10B981',
    },
  ];

  return (
    <View className="px-5 mx-5 py-6 rounded-md border border-neutral-200 mb-6">
      {/* Section Header */}
      <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between mb-4`}>
        <Text className="text-body-lg font-semibold text-gray-900">
          {t('portfolio.investmentPortfoliosTitle')}
        </Text>
        <Pressable>
          
        </Pressable>
      </View>

      {/* Portfolios List */}
      <View className="gap-4">
        {portfolios.map((portfolio) => (
          <Pressable
            key={portfolio.id}
            className="bg-white rounded-2xl p-5 active:opacity-90"
            onPress={() => onOpen?.(portfolio.id)}
          >
            {/* Header Row */}
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-start justify-between mb-3`}>
              <View className={`flex-1 ${isRTL ? 'items-end' : 'items-start'}`}>
                <Text className={`text-body font-semibold text-gray-900 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {portfolio.title}
                </Text>
                <Text className="text-h4 font-bold text-gray-900" riyal riyalColor='black'>
                  {portfolio.amount}
                </Text>
              </View>
              <View className={isRTL ? 'items-start ml-4' : 'items-end mr-0'}>
                <View className={`flex-row py-1 px-2 rounded-full bg-green-500/20 ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center mb-1`}>
                  <TrendingUp size={14} color="#10B981" />
                  <Text className={`text-body-sm text-green-600 ${isRTL ? 'mr-1' : 'ml-1'}`}>
                    {portfolio.change}
                  </Text>
                </View>
               
              </View>
            </View>

            {/* Progress Bar */}
            <View className="w-full relative h-2 bg-neutral-100 rounded-full overflow-hidden">
              <View 
                className="h-full rounded-full" 
                style={{ 
                  backgroundColor: `${portfolio.barColor}20`,
                  width: '100%' 
                }}
              />
              <View className={`absolute h-2 rounded-full ${isRTL ? 'right-0' : 'left-0'}`} style={{ backgroundColor: portfolio.barColor,width: '50%' }} />
            </View>
          </Pressable>
        ))}
      </View>
    </View>
  );
};
