import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '@/components';
import { useTranslation } from 'react-i18next';
import { ChartNoAxesCombined, Settings2, TrendingDown, TrendingUp } from 'lucide-react-native';
interface FundItem {
  id: string;
  title: string;
  amount: string;
  change: string;
  investmentCount: string;
  isPositive: boolean;
  dotColor: string;
}
export const AllocationChart: React.FC = () => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';

  const funds: FundItem[] = [
    {
      id: 'balanced-saudi',
      title: t('portfolio.balancedSaudiFund'),
      amount: '2400.00',
      change: '%12',
      investmentCount: t('portfolio.investmentCount', { count: 8 }),
      isPositive: true,
      dotColor: '#F59E0B',
    },
    {
      id: 'sukuk',
      title: t('portfolio.sukukFund'),
      amount: '2400.00',
      change: '%12',
      investmentCount: t('portfolio.investmentCount', { count: 8 }),
      isPositive: true,
      dotColor: '#EF4444',
    },
    {
      id: 'bonds',
      title: t('portfolio.bonds'),
      amount: '2400.00',
      change: '%12',
      investmentCount: t('portfolio.investmentCount', { count: 178 }),
      isPositive: true,
      dotColor: '#10B981',
    },
    {
      id: 'stocks',
      title: t('portfolio.stocksFund'),
      amount: '2400.00',
      change: '%12',
      investmentCount: t('portfolio.investmentCount', { count: 178 }),
      isPositive: true,
      dotColor: '#0669eaff',
    },
  ];

  return (
    <View className="px-5 mb-6">
      <View className="bg-white rounded-2xl border border-neutral-200 p-5">
        <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center gap-2 mb-4`}>
          <ChartNoAxesCombined size={24} color={'#753AF4'} />
          <Text className="text-h4 font-bold text-gray-900">
            {t('portfolio.distributionAndDetails')}
          </Text>
        </View>

        {/* Circular Charts Row */}
        <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between mb-6`}>
          {funds.map((item) => (
            <View key={item.id} className="items-center">
              {/* Circular Progress */}
              <View className="w-16 h-16 rounded-full border-4 items-center justify-center mb-2" style={{ borderColor: `${item.dotColor}20` }}>
                <Text className="text-body-sm font-bold text-gray-900">{item.change}</Text>
                <View className="absolute  border-4 w-16 h-16 rounded-full" style={{ borderColor: item.dotColor }} />
              </View>
            </View>
          ))}
        </View>

        {/* Description Text */}
        <Text className={`text-body-sm text-gray-600 text-center leading-relaxed ${isRTL ? 'text-right' : 'text-left'}`}>
          {t('portfolio.allocationDescription')}
        </Text>
        <View>
         {funds.map((fund, index) => (
          <View 
            key={fund.id}
            className={`${index !== funds.length - 1 ? 'border-b border-neutral-200' : ''}`}
          >
            <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between p-4`}>
              {/* Left Side: Dot + Title + Subtitle */}
              <View className={`flex-row  ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-start flex-1`}>
                <View 
                  className={`w-4 h-4 rounded-full translate-y-2 ${isRTL ? 'ml-3' : 'mr-3'}`}
                  style={{ backgroundColor: fund.dotColor }}
                />
                <View className="flex-1 b">
                  <Text className={`text-body font-semibold text-gray-900 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {fund.title}
                  </Text>
                  <Text className={`text-body-sm text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {fund.investmentCount}
                  </Text>
                </View>
              </View>

              {/* Right Side: Amount + Change */}
              <View className={ `flex ${isRTL ? 'items-end' : 'items-start'}`}>
                <Text riyalColor='black' riyal={true} className="text-body-lg font-bold text-gray-900 mb-1" >
                  {fund.amount}
                </Text>
                <View className={`flex-row ${isRTL ? 'flex-row' : 'flex-row-reverse'} items-center`}>
                  {fund.isPositive ? (
                    <TrendingUp size={14} color="#10B981" />
                  ) : (
                    <TrendingDown size={14} color="#10B981" />
                  )}
                  <Text className={`text-body-md text-green-600 ${isRTL ? 'mr-1' : 'ml-1'}`}>
                    {fund.change}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        ))}
      </View>
      </View>
      
    </View>
  );
};
