import { useTranslation } from 'react-i18next';
import i18n from 'i18next';
import { useState } from 'react';

/**
 * Hook for managing language switching with persistence
 */
export const useLanguage = () => {
  const { t } = useTranslation();
  const [language, setLanguage] = useState(i18n.language || 'en');

  const switchLanguage = async (lang: 'en' | 'ar') => {
    await i18n.changeLanguage(lang);
    setLanguage(lang);
  };

  const isArabic = language === 'ar';
  const isEnglish = language === 'en';

  return {
    t,
    language,
    switchLanguage,
    isArabic,
    isEnglish,
  };
};

/**
 * Hook for managing bottom sheet state
 */
export const useBottomSheet = (initialState = false) => {
  const [visible, setVisible] = useState(initialState);

  const open = () => setVisible(true);
  const close = () => setVisible(false);
  const toggle = () => setVisible((prev) => !prev);

  return { visible, open, close, toggle };
};

/**
 * Hook for managing modal/dialog state
 */
export const useModal = (initialState = false) => {
  const [visible, setVisible] = useState(initialState);

  const show = () => setVisible(true);
  const hide = () => setVisible(false);
  const toggle = () => setVisible((prev) => !prev);

  return { visible, show, hide, toggle };
};
