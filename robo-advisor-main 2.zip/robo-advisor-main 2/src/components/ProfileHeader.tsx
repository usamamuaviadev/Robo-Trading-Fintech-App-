import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { useTranslation } from 'react-i18next';
import { Bell } from 'lucide-react-native';
import { Text } from '@/components';

export const ProfileHeader: React.FC = () => {
    const { t, i18n } = useTranslation();
    const isRTL = i18n.language === 'ar';
    const [showNotifications, setShowNotifications] = useState(false);

    return (
        <View className={`flex-row ${isRTL ? 'flex-row-reverse' : 'flex-row'} items-center justify-between px-5 pt-3 pb-4`}>
            <View className={`${isRTL ? 'items-end' : 'items-start'}`}>
                <Text className="text-h3 font-bold text-gray-900">
                    {t('home.greeting')}
                </Text>
                <Text className="text-body  text-gray-900">
                    {t('home.subgreeting')}
                </Text>
            </View>

            <Pressable
                onPress={() => setShowNotifications(true)}
                className="w-10 h-10 items-center justify-center"
            >
                <Bell size={24} color="rgba(145, 104, 228, 1)" />
            </Pressable>
        </View>
    );
};