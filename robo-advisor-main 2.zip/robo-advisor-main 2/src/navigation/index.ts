export { RootNavigator } from './RootNavigator';
