import React, { useState } from 'react';
import { Platform, View } from 'react-native';
import { LoadingScreen, SplashScreen, OnboardingScreen } from '../screens';
import { AccountStepScreen } from '@/screens/account/AccountStepScreen';
import { HomeScreen } from '@/screens/home/HomeScreen';
import { PortfolioScreen } from '@/screens/portfolio/PortfolioScreen';
import { PortfolioDetailsScreen } from '@/screens/portfolio/PortfolioDetailsScreen';
import { ConversionsScreen } from '@/screens/conversions/ConversionsScreen';
import { ProfileScreen } from '@/screens/profile/ProfileScreen';
import { SettingsScreen } from '@/screens/profile/SettingsScreen';
import { LanguageScreen } from '@/screens/profile/LanguageScreen';
import { NotificationsScreen } from '@/screens/profile/NotificationsScreen';
import { SecurityScreen } from '@/screens/profile/SecurityScreen';
import { ChangePhoneScreen } from '@/screens/profile/ChangePhoneScreen';
import { VerifyPhoneScreen } from '@/screens/profile/VerifyPhoneScreen';
import { Text } from '@/components';
import { accountSteps } from '@/screens/account/AccountFlowConfig';
import { useTranslation } from 'react-i18next';
import { Edit } from 'lucide-react-native';
import EditProfileScreen from '@/screens/profile/EditProfileScreen';
import ChangeEmailScreen from '@/screens/profile/ChangeEmailScreen';
import DeleteAccountScreen from '@/screens/profile/DeleteAccountScreen';
import AccountsScreen from '@/screens/profile/AccountsScreen';

export type NavigationState =
  | 'loading'
  | 'splash'
  | 'onboarding-1'
  | 'onboarding-2'
  | 'onboarding-3'
  | 'account-1'
  | 'account-2'
  | 'account-3'
  | 'account-4'
  | 'account-5'
  | 'account-6'
  | 'account-7'
  | 'account-8'
  | 'account-9'
  | 'account-10'
  | 'account-11'
  | 'account-12'
  | 'account-13'
  | 'account-14'
  | 'account-15'
  | 'account-16'
  | 'account-17'
  | 'account-18'
  | 'account-19'
  | 'account-20'
  | 'account-21'
  | 'account-22'
  | 'account-23'
  | 'account-24'
  | 'account-25'
  | 'account-26'
  | 'account-27'
  | 'home'
  | 'portfolio'
  | 'portfolio-details'
  | 'conversions'
  | 'account'
  | 'profile-settings'
  | 'profile-accounts'
  | 'profile-language'
  | 'profile-notifications'
  | 'profile-security'
  | 'profile-change-phone'
  | 'profile-verify-phone'
  | 'profile-change-email'
  | 'profile-edit'
  | 'profile-add-account'
  | 'profile-change-password'
  | 'profile-logout-confirm'
  | 'profile-delete-confirm';

export const RootNavigator: React.FC = () => {
  const { t } = useTranslation();
  const [currentScreen, setCurrentScreen] = useState<NavigationState>('home');

  const handleLoadingComplete = () => {
    // Simulate loading delay
    setTimeout(() => setCurrentScreen('splash'), 2000);
  };

  const handleSplashNext = () => {
    setCurrentScreen('onboarding-1');
  };

  const handleOnboardingNext = (current: NavigationState) => {
    const sequence: NavigationState[] = [
      'loading', 'splash',
      'onboarding-1', 'onboarding-2', 'onboarding-3',
      'account-1', 'account-2', 'account-3', 'account-4', 'account-5', 'account-6', 'account-7', 'account-8', 'account-9', 'account-10', 'account-11', 'account-12', 'account-13', 'account-14', 'account-15', 'account-16', 'account-17', 'account-18', 'account-19', 'account-20', 'account-21', 'account-22', 'account-23', 'account-24', 'account-25', 'account-26', 'account-27',
      'home'
    ];
    const idx = sequence.indexOf(current);
    const next = sequence[Math.min(idx + 1, sequence.length - 1)];
    setCurrentScreen(next);
  };

  const handleSkip = () => {
    setCurrentScreen('onboarding-1');
  };

  return (
    <View style={{ flex: 1, backgroundColor: 'transparent', paddingTop: Platform.OS === 'android' ? 25 : 0 }}>
      {currentScreen === 'loading' && (
        <LoadingScreen onLoadingComplete={handleLoadingComplete} />
      )}

      {currentScreen === 'splash' && (
        <SplashScreen onNext={handleSplashNext} />
      )}

      {currentScreen === 'onboarding-1' && (
        <OnboardingScreen
          title={t('onboarding.title1')}
          subtitle={t('onboarding.subtitle1')}
          description={t('onboarding.description1')}
          dotIndex={0}
          totalDots={4}
          onNext={() => handleOnboardingNext('onboarding-1')}
          onSkip={handleSkip}
        />
      )}

      {currentScreen === 'onboarding-2' && (
        <OnboardingScreen
          title={t('onboarding.title2')}
          subtitle={t('onboarding.subtitle2')}
          description={t('onboarding.description2')}
          dotIndex={1}
          totalDots={4}
          onNext={() => handleOnboardingNext('onboarding-2')}
          onSkip={handleSkip}
        />
      )}

      {currentScreen === 'onboarding-3' && (
        <OnboardingScreen
          title={t('onboarding.title3')}
          subtitle={t('onboarding.subtitle3')}
          description={t('onboarding.description3')}
          dotIndex={2}
          totalDots={4}
          onNext={() => handleOnboardingNext('onboarding-3')}
          onSkip={handleSkip}
        />
      )}




      {/* Account creation flow */}
      {currentScreen.startsWith('account-') && (
        <AccountStepScreen
          stepKey={currentScreen}
          onNext={() => handleOnboardingNext(currentScreen)}
          onBack={() => {
            // Simple back logic: find previous in sequence
            const sequence: NavigationState[] = [
              'loading', 'splash', 'onboarding-1', 'onboarding-2', 'onboarding-3',
              'account-1', 'account-2', 'account-3', 'account-4', 'account-5', 'account-6', 'account-7', 'account-8', 'account-9', 'account-10', 'account-11', 'account-12', 'account-13', 'account-14', 'account-15', 'account-16', 'account-17', 'account-18', 'account-19', 'account-20', 'account-21', 'account-22', 'account-23', 'account-24', 'account-25', 'account-26', 'account-27', 'home'
            ];
            const idx = sequence.indexOf(currentScreen);
            const prev = sequence[Math.max(0, idx - 1)];
            setCurrentScreen(prev);
          }}
          onGoToStep={(key) => {
            // Accept only valid account-* keys
            const allowed: NavigationState[] = ['account-1', 'account-2', 'account-3', 'account-4', 'account-5', 'account-6', 'account-7', 'account-8', 'account-9', 'account-10', 'account-11', 'account-12', 'account-13'];
            // Include account-14..account-27 if navigating programmatically
            allowed.push('account-14', 'account-15', 'account-16', 'account-17', 'account-18', 'account-19', 'account-20', 'account-21', 'account-22', 'account-23', 'account-24', 'account-25', 'account-26', 'account-27');
            if (allowed.includes(key as NavigationState)) {
              setCurrentScreen(key as NavigationState);
            }
          }}
          onSelectOption={(id) => {
            // Placeholder: store selection could be added to context/state
            console.log('Selected option', id, 'for', currentScreen);
          }}
        />
      )}
      {currentScreen === 'home' && (
        <HomeScreen onNavigate={setCurrentScreen} />
      )}
      {currentScreen === 'portfolio' && (
        <PortfolioScreen onNavigate={setCurrentScreen} />
      )}
      {currentScreen === 'portfolio-details' && (
        <PortfolioDetailsScreen onBack={() => setCurrentScreen('portfolio')} />
      )}
      {currentScreen === 'conversions' && (
        <ConversionsScreen onNavigate={setCurrentScreen} />
      )}
      {currentScreen === 'account' && (
        <ProfileScreen onNavigate={setCurrentScreen} />
      )}
      {currentScreen === 'profile-settings' && (
        <SettingsScreen onBack={() => setCurrentScreen('account')} />
      )}
      {currentScreen === 'profile-language' && (
        <LanguageScreen onBack={() => setCurrentScreen('account')} />
      )}
      {currentScreen === 'profile-notifications' && (
        <NotificationsScreen onBack={() => setCurrentScreen('account')} />
      )}
      {currentScreen === 'profile-security' && (
        <SecurityScreen
          onBack={() => setCurrentScreen('account')}
          onNavigate={setCurrentScreen}
        />
      )}
      {currentScreen === 'profile-change-phone' && (
        <ChangePhoneScreen
          onBack={() => setCurrentScreen('profile-security')}
          onNavigate={setCurrentScreen}
        />
      )}

      {currentScreen === 'profile-verify-phone' && (
        <VerifyPhoneScreen
          onBack={() => setCurrentScreen('profile-change-phone')}
          onSuccess={() => setCurrentScreen('profile-security')}
        />
      )}
      {currentScreen === 'profile-edit' && (
        <EditProfileScreen
          onBack={() => setCurrentScreen('account')}
          onNavigate={setCurrentScreen}
        />
      )}
      {currentScreen === "profile-change-email" && (
        <ChangeEmailScreen
          onBack={() => setCurrentScreen('account')}
          onNavigate={setCurrentScreen}
        />
      )}
      {
        currentScreen === 'profile-delete-confirm' && (
          <DeleteAccountScreen
          onBack={()=>setCurrentScreen('profile-settings')}
          onDelete={()=>setCurrentScreen('loading')}
          />)
      }
      {
        currentScreen==='profile-accounts'&&(
          <AccountsScreen  onBack={() => setCurrentScreen('profile-settings')} />
        )
      }
    </View>
  );
};
